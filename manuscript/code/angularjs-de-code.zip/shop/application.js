shop = angular.module("Shop", []);

shop.config(function($routeProvider) {
  $routeProvider.
    when('/', { templateUrl: 'articles.html', controller: ArticlesController }).
    when('/about', { templateUrl: 'about.html' }).
    otherwise({ redirectTo: '/'});
});

shop.factory('Cart', function() {
  var items = [];
  return {
    items: items,
    addArticle: function(article) {
      items.push(article);
    },
    copyItem: function(item) {
      return items.splice(items.indexOf(item), 0, item);
    },
    removeItem: function(item) {
      return items.splice(items.indexOf(item),1);
    },
    sum: function() {
      var total = 0;
      angular.forEach(items, function(item){ total += item.price; });
      return total;
    }
  };
});

function CartsController($scope, Cart) {
  $scope.cart = Cart;
  $scope.paymentOptions = ['Bar', 'Paypal', 'Kreditkarte'];
}

function ArticlesController($scope, Cart) {
  $scope.cart = Cart;
  $scope.articles = [
    {id: "1", name: "Pizza Vegetaria", price: 5},
    {id: "2", name: "Pizza Salami",    price: 5.5},
    {id: "3", name: "Pizza Thunfisch", price: 6}
  ];
}