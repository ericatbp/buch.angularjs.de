function MainController($scope) {
  $scope.name = 'AngularJS';
}